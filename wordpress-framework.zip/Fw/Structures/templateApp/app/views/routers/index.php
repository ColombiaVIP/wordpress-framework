<h1><?=$title; ?></h1>
<p><?=$message; ?></p>

<a href="<?=site_url( "{$routeUrl}/saludo" ); ?>">
    Método saludo.
</a>
