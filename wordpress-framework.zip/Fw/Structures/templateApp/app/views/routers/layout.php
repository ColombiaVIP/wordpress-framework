<?php getPart('header'); ?>

<div class="wpfw-layout">
    <?=$content; ?>
</div>

<?php getPart('footer'); ?>