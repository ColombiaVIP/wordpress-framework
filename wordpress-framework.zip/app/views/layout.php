<div class="wpfw-layout">
    <?=$content; ?>
</div>