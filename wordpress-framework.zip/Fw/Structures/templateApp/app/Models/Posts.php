<?php
/**
 * Modelo Posts, ver si se necesita realmente (Creo que en vez de usar WordpressFramework\Models\Model, debería usar Dbout\WpOrm\Orm\AbstractModel asi funcionen las relaciones de serie)
 * 
 */

# namespace;

use WordpressFramework\Models\Model;

class Posts extends Model
{
 
}