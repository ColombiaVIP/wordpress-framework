<?php
/**
 * Modelo abstracto, ver si se necesita realmente.
 * 
 */

namespace WordpressFramework\Models;

use Dbout\WpOrm\Orm\AbstractModel;

abstract class Model extends AbstractModel
{

}